# CampusFlow – Project Report

## 1. Project title
CampusFlow – Student Academic Organizer

## 2. Abstract
CampusFlow is a menu-driven application developed in C to help students organise routine academic activities. It provides modules for subject records, assignment tracking, attendance management and study planning. The application stores information in local files so that records remain available between program sessions.

## 3. Problem statement
Students often manage academic information across notebooks, messages and separate applications. This can make it difficult to track assignment deadlines, attendance and planned study sessions. CampusFlow brings these basic functions together in one simple program.

## 4. Objectives
- Maintain a list of subjects.
- Record and track assignments.
- Calculate attendance percentages from recorded classes.
- Plan study sessions by subject and date.
- Store records locally using C file handling.

## 5. Tools and technologies
- C programming language (C99)
- GCC compiler
- Standard C library
- Git and GitHub for version control and project hosting

## 6. Main modules
### Subject manager
Adds and displays subjects. Each subject has a unique code, name, classes held and classes attended.

### Assignment manager
Adds, lists, completes and deletes assignments. Each assignment stores an ID, subject code, title, due date and completion status.

### Attendance tracker
Records whether a class was attended and calculates the percentage using:
**Attendance percentage = (Classes attended / Classes held) × 100**

### Study planner
Stores a subject code, topic, date and planned duration for each study session.

### File storage
Uses `fopen`, `fread`, `fwrite` and `fclose` to save and load records.

## 7. Data structures
The program uses three structures:
- `Subject`
- `Assignment`
- `StudySession`

Arrays of these structures hold the records while the program is running.

## 8. Testing checklist
- Add a subject and verify it appears in the subject list.
- Try adding a duplicate subject code.
- Add an assignment and verify its details.
- Mark an assignment completed.
- Delete an assignment.
- Record an attended class and a missed class; verify the percentage.
- Add and view a study session.
- Exit and reopen the program; verify that saved records load.

## 9. Limitations
The first version is a local console application for one user. It does not provide automatic notifications, date validation, cloud storage or multiple-user access.

## 10. Future scope
The project can be expanded with SQLite, a graphical interface, a web/mobile front end, secure user accounts, cloud synchronisation, deadline notifications and AI-assisted study recommendations.

## 11. Conclusion
CampusFlow demonstrates how core C programming concepts can be combined to solve a practical student-life problem. Its modular design provides a foundation for future development into a larger academic productivity application.
